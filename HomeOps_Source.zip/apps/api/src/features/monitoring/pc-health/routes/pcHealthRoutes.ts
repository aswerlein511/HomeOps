import { Router } from "express";
import { getPcHealth } from "../controllers/PcHealthController";

const router = Router();

router.get("/", getPcHealth);

export default router;
