import { Request, Response } from "express";
import { PcHealthService } from "../services/PcHealthService";

const service = new PcHealthService();

export async function getPcHealth(
    req: Request,
    res: Response
) {
    const result = await service.getHealth();

    res.json(result);
}
